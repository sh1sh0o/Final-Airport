package com.example.demo.FACEADES;

import com.example.demo.POCOS.*;
import com.example.demo.TOKENS.LoginToken;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * This class operates the all-allowed functions.
 */
@NoArgsConstructor
public class AnonymousFacade extends FacadeBase {

    /**
     * Login function with the user's username and password.
     * @param username The user's username.
     * @param password The user's password.
     * @return The compatible facade of the logged-in user.
     */
    public FacadeBase login(String username, String password){
        UserPOCO userPOCO=userDAO.get_user_by_username(username);
        if(userPOCO==null)
            return null;


        if(userPOCO.getPassword().equals(password)) {
            if (userPOCO.getUser_Role() == 1) {//customer
                CustomerPOCO customerPOCO=customerDAO.get_customer_by_username(username);
                return new CustomerFacade(new LoginToken(customerPOCO.getId(), customerPOCO.getFirst_Name(), 1));
            }
            else if(userPOCO.getUser_Role() == 2){//airline company
                AirlineCompanyPOCO airlineCompanyPOCO=airlineCompaniesDAO.get_airline_by_username(username);
                return new AirlineFacade(new LoginToken(airlineCompanyPOCO.getId(), airlineCompanyPOCO.getName(), 2));
            }
            else if(userPOCO.getUser_Role() == 3){//administrator
                AdministratorPOCO administratorPOCO=administratorDAO.get_administrator_by_user_id(userPOCO.getId());
                return new AdministratorsFacade(new LoginToken(administratorPOCO.getId(), administratorPOCO.getFirst_Name(), 3));
            }
        }
        return null;
    }

    /**
     * Adds a customer user.
     * @param userPOCO The user's details.
     * @param customerPOCO The user's customer-details.
     */
    public void add_customer(UserPOCO userPOCO,CustomerPOCO customerPOCO){
        if(customerPOCO==null||userPOCO==null)
            return;
       if( customerDAO.Add(customerPOCO)) {
           System.out.println("got in");
           customerPOCO=customerDAO.get_customer_by_Phone_No(customerPOCO.getPhone_No());
           System.out.println(customerPOCO);
           userPOCO.setId(customerPOCO.getId());
           create_new_user(userPOCO);
           customerPOCO.setUser_Id(userPOCO.getId());
           customerDAO.Update(customerPOCO);
           System.out.println("customer create");
       }

    }


}
