package com.example.demo.DTO;

import org.springframework.data.repository.CrudRepository;

public interface ContactUsRepo extends CrudRepository<ContactUs,Integer> {

}
