package com.example.demo.FACEADES;

import com.example.demo.POCOS.*;
import com.example.demo.DAOS.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.ArrayList;

/**
 * This abstract class is the base of all facades.
 */
@NoArgsConstructor
@AllArgsConstructor
public abstract class FacadeBase {
    FlightDAO flightDAO=new FlightDAO();
    AirlineCompaniesDAO airlineCompaniesDAO=new AirlineCompaniesDAO();
    CountryDAO countryDAO=new CountryDAO();
    UserDAO userDAO=new UserDAO();
    CustomerDAO customerDAO=new CustomerDAO();
    AdministratorDAO administratorDAO=new AdministratorDAO();

    /**
     * Returns a flight POCO list
     * @return
     */
    public ArrayList<FlightPOCO> get_all_flights() {
        return flightDAO.GetAll();
    }


    public FlightPOCO get_flight_by_id(long _id) {
        return (FlightPOCO) flightDAO.Get(_id);
    }

    public ArrayList<FlightPOCO> get_flights_by_parameters(int origin_country_id,
                                                           int destination_country,Timestamp date){
        return flightDAO.get_flights_by_parameters(origin_country_id,destination_country,date);
    }
    public ArrayList<AirlineCompanyPOCO> get_all_airlines() {
        return airlineCompaniesDAO.GetAll();
    }

    public AirlineCompanyPOCO get_airline_by_id(long id) {

        return (AirlineCompanyPOCO) airlineCompaniesDAO.Get(id);
    }

    public AirlineCompanyPOCO get_airline_by_parameters(String name, int country_id) {
        return airlineCompaniesDAO.get_airline_by_parameters(name,country_id);
    }
    public ArrayList<CountryPOCO> get_all_countries() {

        return countryDAO.GetAll();
    }
    public CountryPOCO get_country_by_id(int _id) {

        return (CountryPOCO) countryDAO.Get(_id);
    }
    public UserPOCO create_new_user(UserPOCO userPOCO) {
        if(userPOCO==null||userPOCO.getPassword().length()<6)
            return null;
        userPOCO.setUser_Role(1);
       userDAO.Add(userPOCO);
           System.out.println("user create");
           return userPOCO;
           
//        customerPOCO.setUser_Id(userPOCO.getId());
//        customerDAO.Add(customerPOCO);
    }
}
