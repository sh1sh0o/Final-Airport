package com.example.demo.POCOS;

/**
 * POCO interface to be implemented by the different pocos.
 */
public interface POCO {
}
