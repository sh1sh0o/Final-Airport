package com.example.demo.POCOS;
/**
 * This class represents a record of "Customers" table in the database
 */
public class CustomerPOCO implements POCO{
        long Id;
        String First_Name;
        String Last_Name;
        String Address;
        String Phone_No;
        String Credit_Card_No;
        long User_Id;

    @Override
    public String toString() {
        return "CustomerPOCO{" +
                "Id=" + Id +
                ", First_Name='" + First_Name + '\'' +
                ", Last_Name='" + Last_Name + '\'' +
                ", Address='" + Address + '\'' +
                ", Phone_No='" + Phone_No + '\'' +
                ", Credit_Card_No='" + Credit_Card_No + '\'' +
                ", User_Id=" + User_Id +
                '}';
    }

    public CustomerPOCO() {
    }

    public CustomerPOCO(long id, String first_Name, String last_Name, String address, String phone_No, String credit_Card_No, long user_Id) {
        Id = id;
        First_Name = first_Name;
        Last_Name = last_Name;
        Address = address;
        Phone_No = phone_No;
        Credit_Card_No = credit_Card_No;
        User_Id = user_Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public void setFirst_Name(String first_Name) {
        First_Name = first_Name;
    }

    public void setLast_Name(String last_Name) {
        Last_Name = last_Name;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public void setPhone_No(String phone_No) {
        Phone_No = phone_No;
    }

    public void setCredit_Card_No(String credit_Card_No) {
        Credit_Card_No = credit_Card_No;
    }

    public void setUser_Id(long user_Id) {
        User_Id = user_Id;
    }

    public long getId() {
        return Id;
    }

    public String getFirst_Name() {
        return First_Name;
    }

    public String getLast_Name() {
        return Last_Name;
    }

    public String getAddress() {
        return Address;
    }

    public String getPhone_No() {
        return Phone_No;
    }

    public String getCredit_Card_No() {
        return Credit_Card_No;
    }

    public long getUser_Id() {
        return User_Id;
    }

}
