package com.example.demo.POCOS;

/**
 * This class represents a record of "Flights" table in the database
 */
public class FlightPOCO implements POCO{
    long id;
    long Airline_Company_Id;
    int Origin_Country_Id;
    int Destination_Country_Id;
    int Remaining_Tickets;
    java.sql.Timestamp Departure_Time;
    java.sql.Timestamp Landing_Time;


    public FlightPOCO() {
    }

    public FlightPOCO(long id, long airline_Company_Id, int origin_Country_Id, int destination_Country_Id, int remaining_Tickets, java.sql.Timestamp departure_Time, java.sql.Timestamp landing_Time) {
        this.id = id;
        Airline_Company_Id = airline_Company_Id;
        Origin_Country_Id = origin_Country_Id;
        Destination_Country_Id = destination_Country_Id;
        Departure_Time = departure_Time;
        Landing_Time = landing_Time;
        Remaining_Tickets = remaining_Tickets;

    }

    public void setId(long id) {
        this.id = id;
    }

    public void setAirline_Company_Id(long airline_Company_Id) {
        Airline_Company_Id = airline_Company_Id;
    }

    public void setOrigin_Country_Id(int origin_Country_Id) {
        Origin_Country_Id = origin_Country_Id;
    }

    public void setDestination_Country_Id(int destination_Country_Id) {
        Destination_Country_Id = destination_Country_Id;
    }

    public void setDeparture_Time(java.sql.Timestamp departure_Time) {
        Departure_Time = departure_Time;
    }

    public void setLanding_Time(java.sql.Timestamp landing_Time) {
        Landing_Time = landing_Time;
    }

    public void setRemaining_Tickets(int remaining_Tickets) {
        Remaining_Tickets = remaining_Tickets;
    }

    public long getId() {
        return id;
    }

    public long getAirline_Company_Id() {
        return Airline_Company_Id;
    }

    public int getOrigin_Country_Id() {
        return Origin_Country_Id;
    }

    public int getDestination_Country_Id() {
        return Destination_Country_Id;
    }

    public java.sql.Timestamp getDeparture_Time() {
        return Departure_Time;
    }

    public java.sql.Timestamp getLanding_Time() {
        return Landing_Time;
    }

    public int getRemaining_Tickets() {
        return Remaining_Tickets;
    }

    @Override
    public String toString() {
        return "FlightPOCO{" +
                "id=" + id +
                ", Airline_Company_Id=" + Airline_Company_Id +
                ", Origin_Country_Id=" + Origin_Country_Id +
                ", Destination_Country_Id=" + Destination_Country_Id +
                ", Remaining_Tickets=" + Remaining_Tickets +
                ", Departure_Time=" + Departure_Time +
                ", Landing_Time=" + Landing_Time +"\n"+
                '}';
    }

}
