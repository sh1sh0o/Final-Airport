package com.example.demo.POCOS;
/**
 * This class represents a record of "Airline_Companies" table in the database
 */
public class AirlineCompanyPOCO implements POCO{
    long Id;
    String Name;
    int Country_Id;
    long User_Id;

    public AirlineCompanyPOCO() {
    }

    @Override
    public String toString() {
        return "AirlineCompanyPOCO{" +
                "Id=" + Id +
                ", Name='" + Name + '\'' +
                ", Country_Id=" + Country_Id +
                ", User_Id=" + User_Id +
                '}';
    }

    public AirlineCompanyPOCO(long id, String name, int country_Id, long user_Id) {
        Id = id;
        Name = name;
        Country_Id = country_Id;
        User_Id = user_Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public void setName(String name) {
        Name = name;
    }

    public void setCountry_Id(int country_Id) {
        Country_Id = country_Id;
    }

    public void setUser_Id(long user_Id) {
        User_Id = user_Id;
    }

    public long getId() {
        return Id;
    }

    public String getName() {
        return Name;
    }

    public int getCountry_Id() {
        return Country_Id;
    }

    public long getUser_Id() {
        return User_Id;
    }
}
