package com.example.demo.DTO;


import lombok.*;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Entity
public class ContactUs{
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    private String senderName;
    private String email;
    private String content;
}
