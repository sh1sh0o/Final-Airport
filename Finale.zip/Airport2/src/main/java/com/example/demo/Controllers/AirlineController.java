package com.example.demo.Controllers;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.example.demo.DAOS.AirlineCompaniesDAO;
import com.example.demo.DAOS.UserDAO;
import com.example.demo.FACEADES.AirlineFacade;
import com.example.demo.POCOS.AirlineCompanyPOCO;
import com.example.demo.POCOS.FlightPOCO;
import com.example.demo.POCOS.UserPOCO;
import com.example.demo.TOKENS.LoginToken;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;

@RestController
@RequestMapping("/airline")
public class AirlineController{


    @GetMapping("/get_my_flights")
    public ArrayList<FlightPOCO> get_my_flights(@RequestHeader LoginToken loginToken){
        if(loginToken.getRole()!=2)
            return null;
        AirlineFacade air=new AirlineFacade(loginToken);
       return air.get_my_flights();
    }

    @PutMapping("/update_airline")
    public void update_airline(@RequestBody AirlineCompanyPOCO airlineCompanyPOCO, @RequestHeader LoginToken loginToken){
        if(loginToken.getRole()!=2)
            return ;
        AirlineFacade air=new AirlineFacade(loginToken);
        air.update_airline(airlineCompanyPOCO);
    }

    @PostMapping("/add_flight")
    public void add_flight(@RequestBody FlightPOCO flightPOCO, @RequestHeader LoginToken loginToken){
        
        AirlineFacade air=new AirlineFacade(loginToken);
        air.add_flight(flightPOCO);
    }

    @PutMapping("/update_flight")
    public void update_flight(@RequestBody FlightPOCO flightPOCO,@RequestHeader LoginToken loginToken){

        AirlineFacade air=new AirlineFacade(loginToken);
        air.update_flight(flightPOCO);
    }

    @PutMapping("/remove_flight")
    public void remove_flight(@RequestBody FlightPOCO flightPOCO){
        AirlineFacade air=new AirlineFacade();
        air.remove_flight(flightPOCO);
    }

//    UserPOCO getIt(HttpServletRequest request){
//        String authorizationHeader = request.getHeader(AUTHORIZATION);
//        String token = authorizationHeader.substring(7);
//        Algorithm algorithm = Algorithm.HMAC256("secret".getBytes());
//        JWTVerifier verifier = JWT.require(algorithm).build();
//        DecodedJWT decodedJWT = verifier.verify(token);
//        String username = decodedJWT.getSubject();
//
//        AirlineFacade air=new AirlineFacade();
//        UserDAO userDao=new UserDAO();
//        return userDao.get_user_by_username(username);
//    }

    @Data
    class RoleToUserForm{
        private String username;
        private String roleName;
    }

}
