package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import com.example.demo.DTO.AppUser;
import com.example.demo.DTO.Role;
import com.example.demo.service.UserService;
import org.apache.tomcat.jni.User;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.ArrayList;

@SpringBootApplication
public class Airport2Application {

	public static void main(String[] args) {
		SpringApplication.run(Airport2Application.class, args);
	}
	@Bean
	PasswordEncoder passwordEncoder(){
		return new BCryptPasswordEncoder();
	}


////	@Bean
////	CommandLineRunner run(UserService userService){
////		return args -> {
////			userService.saveRole(new Role(null,"CUSTOMER"));
////			userService.saveRole(new Role(null,"AIRLINE"));
////			userService.saveRole(new Role(null,"ADMIN"));
////
////			userService.saveUser(new AppUser(null,"John Travolta","John","1234",new ArrayList<>()));
////			userService.saveUser(new AppUser(null,"Johny Travolta","Johny","1234",new ArrayList<>()));
////			userService.saveUser(new AppUser(null,"Roi Travolta","Roi","1234",new ArrayList<>()));
////			userService.saveUser(new AppUser(null,"Shai Travolta","Shai","1234",new ArrayList<>()));
////
////			userService.addRoleToUser("John","AIRLINE");
////			userService.addRoleToUser("Johny","CUSTOMER");
////			userService.addRoleToUser("Roi","ADMIN");
////			userService.addRoleToUser("Shai","AIRLINE");
////		};
//	}

}
