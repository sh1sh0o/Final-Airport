package com.example.demo.Controllers;

import com.example.demo.FACEADES.AdministratorsFacade;
import com.example.demo.POCOS.AdministratorPOCO;
import com.example.demo.POCOS.AirlineCompanyPOCO;
import com.example.demo.POCOS.CustomerPOCO;
import com.example.demo.POCOS.UserPOCO;
import com.example.demo.TOKENS.LoginToken;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
@Data
@RestController
@RequestMapping("/admin")
public class AdminController {


    @GetMapping("/get_all_customers")
    public ArrayList<CustomerPOCO> get_all_customers(@RequestHeader LoginToken loginToken){
        if(loginToken.getRole()!=3)
            return null;
        AdministratorsFacade administratorsFacade=new AdministratorsFacade();
        return administratorsFacade.get_all_customers();
    }

    @PostMapping("/create_new_user")
    public UserPOCO create_new_user(@RequestBody UserPOCO userPOCO, @RequestHeader LoginToken loginToken) {
        if(loginToken.getRole()!=3)
            return null;
        AdministratorsFacade administratorsFacade=new AdministratorsFacade();
        return administratorsFacade.create_new_user(userPOCO);
    }

    @PostMapping("/add_airline")
    public void add_airline(@RequestBody AirlineCompanyPOCO airlineCompanyPOCO,@RequestBody UserPOCO userPOCO, @RequestHeader LoginToken loginToken){
        AdministratorsFacade administratorsFacade=new AdministratorsFacade();
        administratorsFacade.add_airline(airlineCompanyPOCO,userPOCO);
    }

    @PostMapping("/add_administrator")
    public void add_administrator(@RequestBody AdministratorPOCO administratorPOCO,@RequestBody UserPOCO userPOCO, @RequestHeader LoginToken loginToken){
        if(loginToken.getRole()!=3)
            return ;
        AdministratorsFacade administratorsFacade=new AdministratorsFacade();
        administratorsFacade.add_administrator(administratorPOCO,userPOCO);
    }

    @DeleteMapping("/remove_airline")
    public void remove_airline(@RequestBody AirlineCompanyPOCO airlineCompanyPOCO, @RequestHeader LoginToken loginToken){
        AdministratorsFacade administratorsFacade=new AdministratorsFacade();
        administratorsFacade.remove_airline(airlineCompanyPOCO);
    }

    @DeleteMapping("/remove_customer")
    public void remove_customer(@RequestBody CustomerPOCO customerPOCO, @RequestHeader LoginToken loginToken){
        AdministratorsFacade administratorsFacade=new AdministratorsFacade();
        administratorsFacade.remove_customer(customerPOCO);
    }

    @DeleteMapping("/remove_administrator")
    public void remove_administrator(@RequestBody AdministratorPOCO administratorPOCO, @RequestHeader LoginToken loginToken){
        AdministratorsFacade administratorsFacade=new AdministratorsFacade();
        administratorsFacade.remove_administrator(administratorPOCO);
    }


}
