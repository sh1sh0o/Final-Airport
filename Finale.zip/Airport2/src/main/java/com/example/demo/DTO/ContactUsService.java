package com.example.demo.DTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ContactUsService {
    @Autowired
    ContactUsRepo contactUsRepo;

    public List<ContactUs> getAllContactUs(){
        List<ContactUs> contactUses=new ArrayList<>();
        contactUsRepo.findAll().forEach(contactUses::add);
        return contactUses;

    }

    public ContactUs getContactUs(int id){
        var res=contactUsRepo.findById(id);
        return res.orElse(null);
    }

    public void addContactUs(ContactUs contactUs){
        contactUsRepo.save(contactUs);
    }
}
