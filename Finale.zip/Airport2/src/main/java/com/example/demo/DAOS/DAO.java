package com.example.demo.DAOS;

import java.util.ArrayList;
/**
 * DAO interface to be implemented by the different DAOS.
 */
public interface DAO<T> {
    /**
     * Returns a POCO by its id.
     * @param id The id of the wanted POCO.
     * @return a POCO by its id.
     */
    Object Get(long id);

    /**
     * Returns a POCO list of all the registers in the table.
     * @return a POCO list of all the registers in the table.
     */
    ArrayList<T> GetAll();

    /**
     * Adds a register to the table in the database.
     * @param t The register to add
     * @return True if the Add of a register to the table in the database is succeeded.
     */
    boolean Add(T t);

    /**
     * Removes a register from the table in the database.
     * @param t The register to remove.
     */
    void Remove(T t);

    /**
     * Updates a register from the table in the database.
     * @param t The register to update.
     */
    void Update(T t);





}
