package com.example.demo.POCOS;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * This class represents a record of "Users" table in the database
 */
@Getter
@Setter
public class UserPOCO implements POCO{
   private long Id;
   private String Username;
   private String Password;
   private String Email;
   private int User_Role;

    public UserPOCO() {
    }

    public UserPOCO(long id, String user_Name, String password, String email, int user_Role) {
        Id = id;
        Username = user_Name;
        Password = password;
        Email = email;
        User_Role = user_Role;
    }

    @Override
    public String toString() {
        return "UserPOCO{" +
                "Id=" + Id +
                ", Username='" + Username + '\'' +
                ", Password='" + Password + '\'' +
                ", Email='" + Email + '\'' +
                ", User_Role=" + User_Role +
                '}';
    }
}
