package com.example.demo.DAOS;


import com.example.demo.POCOS.*;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
/**
 * This class is being use for interfacing with the "Countries" table in the database
 */

public class CountryDAO implements DAO<CountryPOCO> {
    private PostgresqlConnection connection = new PostgresqlConnection();
    private ArrayList<CountryPOCO> list = new ArrayList<>();
    private String db = "AirPortDB";
    private Connection con = connection.getConnection(db,"791988ss");
    private Statement statement = connection.getStatement();


    @Override
    public Object Get(long id) {
        CountryPOCO poco = new CountryPOCO();
        try {
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Countries\"\n" +
                    "where \"Countries\".\"Id\"=" + id);
            poco.setId(result.getInt("Id"));
            poco.setName(result.getString("Name"));
            result.close();
        } catch (Exception e) {

        }

        return poco;
    }

    @Override
    public ArrayList<CountryPOCO> GetAll() {
        try {
            list.clear();
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Countries\"");
            while (result.next()) {
                CountryPOCO p1 = new CountryPOCO(result.getInt("Id"), result.getString("Name"));
                list.add(p1);
            }
            result.close();
        } catch (Exception e) {

        }

        return list;
    }


    @Override
    public boolean Add(CountryPOCO o) {

        try {
            var result = statement.executeUpdate("insert into \"Countries\"(\"Name\")" +
                    "values(\n" +
                   "\'"+ o.getName()+"\'" +
                    "\t\n" +
                    ")");
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public void Remove(CountryPOCO o) {
        if(o==null)
            return;
        try {
            var result = statement.executeUpdate("delete  from \"Countries\"\n" +
                    "where \"Id\"=" + o.getId());

        } catch (Exception e) {

        }
    }

    @Override
    public void Update(CountryPOCO o) {
        if(o==null)
            return;
        try {
            ResultSet result = statement.executeQuery("UPDATE \"Countries\"\n" +
                    "SET \"Id\" =" + o.getId() + ", \"Name\" =" + "\'"+o.getName()+"\'"  +
                    "where \"Id\"=" + o.getId());

            result.close();
        } catch (Exception e) {

        }
    }





}
