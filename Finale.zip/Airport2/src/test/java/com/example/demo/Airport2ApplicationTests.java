package com.example.demo;

import com.example.demo.DAOS.*;
import com.example.demo.FACEADES.AirlineFacade;
import com.example.demo.POCOS.*;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class Airport2ApplicationTests {
//	CustomerDAO customerDAO=new CustomerDAO();
//	TicketDAO ticketDAO=new TicketDAO();
//	AirlineCompaniesDAO airlineCompaniesDAO=new AirlineCompaniesDAO();
//
//	@Test
//	void testAnonymousController() {
//		Assert.assertEquals(TestStatic.get("http://localhost:8080/anonymous/get_all_countries", CountryPOCO.class),new CountryDAO().GetAll());
//	}
//
//	@Test
//	void testAirlineController() {
//		AirlineCompanyPOCO airlineCompanyPOCO=(AirlineCompanyPOCO) airlineCompaniesDAO.Get(1);
//		Assert.assertEquals(TestStatic.get("http://localhost:8080/airline/get_my_flights", FlightPOCO.class),new FlightDAO().get_flights_by_airline_company(airlineCompanyPOCO));
//	}
//
//	@Test
//	void testCustomerController() {
//
//		CustomerPOCO c=(CustomerPOCO) customerDAO.Get(1);
//		Assert.assertEquals(TestStatic.get("http://localhost:8080/customer/get_my_tickets", TicketPOCO.class),ticketDAO.get_tickets_by_customer(1));
//	}
//
//	@Test
//	void testAdminController() {
//
//		Assert.assertEquals(TestStatic.get("http://localhost:8080/admin/get_all_customers", CustomerPOCO.class),customerDAO.GetAll());
//	}

}
